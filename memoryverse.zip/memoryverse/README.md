# ◈ MemoryVerse

> **Where every memory finds its forever home.**

A full-stack web app for capturing, preserving, and reliving your most precious memories — with real-time mood detection, dynamic theme switching, and curated music recommendations.

---

## 🗂️ Project Structure

```
memoryverse/
│
├── app.py                  ← Flask backend (API routes, mood detection, music)
├── memories.json           ← Auto-created JSON database
├── requirements.txt        ← Python dependencies
├── README.md               ← This file
│
├── templates/
│   └── index.html          ← Main HTML page (Jinja2 template)
│
└── static/
    ├── css/
    │   └── style.css       ← Full stylesheet (glassmorphism, animations, themes)
    ├── js/
    │   └── app.js          ← Frontend JS (particles, API calls, rendering)
    └── uploads/            ← User-uploaded images (auto-created)
```

---

## 🚀 Quick Start

### 1. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Flask server

```bash
python app.py
```

### 3. Open your browser

```
http://localhost:5000
```

---

## ✨ Features

| Feature | Description |
|---|---|
| 🎥 Cinematic Hero | Animated landing with floating particles, aurora orbs |
| 📝 Memory Form | Add title, date, description, and photo |
| 🧠 Mood Detection | Real-time text analysis detects 6 moods as you type |
| 🎨 Dynamic Themes | Page colors shift to match detected mood |
| 📅 Timeline | Alternating card layout with scroll-reveal animations |
| 🎵 Music Recs | 4 curated songs per mood, with Spotify search links |
| 🔍 Mood Filter | Filter timeline by emotional category |
| 🪟 Memory Modal | Click any card to open a full-screen detail view |
| 📱 Responsive | Works beautifully on desktop, tablet, and mobile |
| 💾 JSON Storage | Memories stored in `memories.json` — no database needed |

---

## 🎭 Mood Themes

| Mood | Colors | Vibe |
|---|---|---|
| 😊 Happy | Gold + Orange | Warm, radiant |
| 💙 Sad | Violet + Lavender | Deep, introspective |
| ⚡ Excited | Pink + Magenta | Electric, vibrant |
| 🌿 Peaceful | Cyan + Aqua | Serene, calm |
| 📻 Nostalgic | Terracotta + Amber | Warm, hazy |
| 🌀 Anxious | Teal + Mint | Soothing, grounded |

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/memories` | Fetch all memories |
| POST | `/api/memories` | Add a new memory (multipart/form-data) |
| DELETE | `/api/memories/<id>` | Delete a memory by UUID |
| POST | `/api/mood` | Detect mood + get music recs from text |

---

## 🛠️ Tech Stack

- **Backend**: Python 3.10+ · Flask · JSON file storage
- **Frontend**: Vanilla HTML5 · CSS3 (custom properties, keyframes) · ES2024 JavaScript
- **Design**: Glassmorphism · Aurora gradients · Canvas particle system
- **Fonts**: Cormorant Garamond · DM Sans · JetBrains Mono

---

*Built with ❤️ using Flask + HTML + CSS + JavaScript*
